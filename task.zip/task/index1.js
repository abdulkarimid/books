 
 
  $(document).ready(function(){
   
    logout();
  });
  ajaxData={};
  ck=0;
  /* rootRef={}; */
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    
    // User is signed in.
    userId=user.uid;
    //alert(userId);
    var date = new Date();
    var n = date.toDateString();
    var time = date.toLocaleTimeString();
    datetime=n+" "+time;
    snapcity="";
    if(ck===0){
        check(userId,snapcity,ck);
    }else{
        writeUserData(userId,ajaxData.geoplugin_request,ajaxData.geoplugin_city,datetime);
    }
    var database = firebase.database();

    

    //var user = firebase.auth().currentUser;
    
    if(user != null){

      var email_id = user.email;
      document.getElementById("user_para").innerHTML = "Welcome User : " + email_id;
      console.log('data');
      console.log(ajaxData);
      html="<p>ip: "+ajaxData.geoplugin_request+"</p><p>Country Code: +44</p><p>Country: "+ajaxData.geoplugin_countryName+"</p><p>Country Abbrevation: "+ajaxData.geoplugin_countryCode+"</p><p>Region Code: "+ajaxData.geoplugin_regionCode+"</p><p>Region Name: "+ajaxData.geoplugin_regionName+"</p><p>City: "+ajaxData.geoplugin_city+"</p><p>Time Zone: "+ajaxData.geoplugin_timezone+"</p><p>Latitude: "+ajaxData.geoplugin_latitude+"</p><p>Longitude: "+ajaxData.geoplugin_longitude+"</p><p>Last Login: "+datetime+"</p>";
      $('#data').html(html);

    }

  } else {
    // No user is signed in.

    document.getElementById("user_div").style.display = "none";
    document.getElementById("login_div").style.display = "block";

  }
});
function check(userId,snapcity,ck){
  var rootRef=firebase.database().ref().child('users');
  rootRef.child(userId).once('value', function(snap){
    snapcity = snap.child("city").val();
    console.log(snapcity, ajaxData.geoplugin_city);
    if(snapcity){
      if(snapcity!=ajaxData.geoplugin_city){
        
        logout();
        alert("you can't login because previously you were logged from: "+snapcity );
      }else{
        
        writeUserData(userId,ajaxData.geoplugin_request,ajaxData.geoplugin_city,datetime);
      }
    }
  });
  /* console.log(snapcity);
      console.log(ajaxData.geoplugin_city);
  if(snapcity){
    if(snapcity!=ajaxData.geoplugin_city){
      logout();
      alert("you can't login because previously you were logged from "+snapcity );
      
    }
  } */
}
function writeUserData(userId, ip, city,datetime) {
  //alert(userId);
  //alert(ip);
  //alert(datetime);
  document.getElementById("user_div").style.display = "block";
  document.getElementById("login_div").style.display = "none";
  firebase.database().ref('users/' + userId).set({
    userId:userId,
    ip: ip,
    city: city,
    date:datetime
    //some more user data
  });
}

function login(){
  var userEmail = document.getElementById("email_field").value;
  var userPass = document.getElementById("password_field").value;
  
    
        ajaxData.geoplugin_request=geoplugin_request();
        ajaxData.geoplugin_countryName=geoplugin_countryName();
        ajaxData.geoplugin_countryCode=geoplugin_countryCode();
        ajaxData.geoplugin_regionCode=geoplugin_regionCode();
        ajaxData.geoplugin_regionName=geoplugin_regionName();
        ajaxData.geoplugin_city=geoplugin_city();
        ajaxData.geoplugin_timezone=geoplugin_timezone();
        ajaxData.geoplugin_latitude=geoplugin_latitude();
        ajaxData.geoplugin_longitude=geoplugin_longitude();
        
        console.log(data);
        
          if(ajaxData.geoplugin_countryCode=='GB'){
              ck=0;
            firebase.auth().signInWithEmailAndPassword(userEmail, userPass).catch(function(error) {
              // Handle Errors here.
              var errorCode = error.code;
              var errorMessage = error.message;
          
              window.alert("Error : " + errorMessage);
          
              // ...
            });
          }
          else{
              alert("You are not allowed to login outside the uk region");
          }
      }



function create_account(){

  var userEmail = document.getElementById("email_field").value;
  var userPass = document.getElementById("password_field").value;
 
        ajaxData.geoplugin_request=geoplugin_request();
        ajaxData.geoplugin_countryName=geoplugin_countryName();
        ajaxData.geoplugin_countryCode=geoplugin_countryCode();
        ajaxData.geoplugin_regionCode=geoplugin_regionCode();
        ajaxData.geoplugin_regionName=geoplugin_regionName();
        ajaxData.geoplugin_city=geoplugin_city();
        ajaxData.geoplugin_timezone=geoplugin_timezone();
        ajaxData.geoplugin_latitude=geoplugin_latitude();
        ajaxData.geoplugin_longitude=geoplugin_longitude();
        
        console.log(data);
        
        if(ajaxData.geoplugin_countryCode=='GB'){
            ck=1;
          firebase.auth().createUserWithEmailAndPassword(userEmail, userPass).catch(function(error) {
            // Handle Errors here.
            var errorCode = error.code;
            var errorMessage = error.message;
        
            window.alert("Error : " + errorMessage);
        
            // ...
          });
        }
        else{
            alert("You are not allowed to login outside the uk region");
        }
    }

function logout(){
  ajaxData={};
  firebase.auth().signOut();
}
