<html>
<head>
  <title>Firebase Login</title>
  <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <div id="login_div" class="main-div">
    <h3>Firebase Web Sign in / Sign Up</h3>
    <input type="email" placeholder="Email..." id="email_field" />
    <input type="password" placeholder="Password..." id="password_field" />

    <button onclick="login()">Login to Account</button>
    <br>
    <button onclick="create_account()">Create a New Account</button>
  </div>

  <div id="user_div" class="loggedin-div">
    <h3>Welcome</h3>
    <p id="user_para">Welcome to Firebase web login Example. You're currently logged in.</p>
    <div id="data"></div>
    <button onclick="logout()">Logout</button>
  </div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!--<script src="https://code.jquery.com/jquery-migrate-3.0.1.js"></script>-->
<script src="https://www.gstatic.com/firebasejs/5.7.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyASBH_3XDqmEiff5KDN-aTt0EUwxW2jEJQ",
    authDomain: "agappe-web.firebaseapp.com",
    databaseURL: "https://agappe-web.firebaseio.com",
    projectId: "agappe-web",
    storageBucket: "agappe-web.appspot.com",
    messagingSenderId: "540229630340"
  };
  firebase.initializeApp(config);
</script>
<script language="JavaScript" src="http://www.geoplugin.net/javascript.gp" type="text/javascript"></script>
  <script src="index1.js"></script>

</body>
</html>
